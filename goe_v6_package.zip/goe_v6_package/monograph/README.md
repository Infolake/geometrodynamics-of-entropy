# Geometrodynamics of Entropy

This folder should contain the full text of the monograph (v6.0).