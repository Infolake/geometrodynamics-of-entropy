# Geometrodynamics of Entropy – Project Package (v6.0)

## Quick Start
```bash
git clone <repo-url>
cd geometrodynamics-of-entropy
conda env create -f environment.yml
conda activate goe_env
jupyter lab notebooks/01_Cumulative_Mass_Matrix.ipynb
```

This package contains the full directory structure ready for use.
